package es.ucm.tp1.control.exceptions;

public class NotEnoughCoinsException extends CommandExecuteException {

	public NotEnoughCoinsException(String msg) {
		super(msg);
	}

}
