package es.ucm.tp1.control.exceptions;

public class CommandExecuteException extends GameException {

	public CommandExecuteException(String msg) {
		super(msg);
	}

}
