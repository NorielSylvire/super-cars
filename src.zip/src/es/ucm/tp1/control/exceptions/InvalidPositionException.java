package es.ucm.tp1.control.exceptions;

public class InvalidPositionException extends CommandExecuteException {

	public InvalidPositionException(String msg) {
		super(msg);
	}

}
