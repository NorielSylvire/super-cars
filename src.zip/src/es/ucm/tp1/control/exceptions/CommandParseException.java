package es.ucm.tp1.control.exceptions;

public class CommandParseException extends GameException {

	public CommandParseException(String msg) {
		super(msg);
	}

}
