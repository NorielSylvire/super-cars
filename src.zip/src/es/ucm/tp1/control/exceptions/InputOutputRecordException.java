package es.ucm.tp1.control.exceptions;

public class InputOutputRecordException extends CommandExecuteException {

	public InputOutputRecordException(String msg) {
		super(msg);
	}

}
