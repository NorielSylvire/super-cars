package es.ucm.tp1.control;

import es.ucm.tp1.logic.Game;

public interface IInstantAction {
	
	void executeIA(Game game);
	public static void staticExecuteIA(Game game) {
		
	}

}
