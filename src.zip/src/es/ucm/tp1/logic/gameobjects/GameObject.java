package es.ucm.tp1.logic.gameobjects;

public class GameObject {

}
